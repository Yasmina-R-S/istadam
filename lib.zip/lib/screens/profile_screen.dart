import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  final Map<String, dynamic> user;
  final List<Map<String, dynamic>> posts;

  const ProfileScreen({super.key, required this.user, required this.posts});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(user['username']),
        centerTitle: false,
      ),
      body: Column(
        children: [
          _header(),
          _editButton(),
          const Divider(),
          Expanded(child: _grid()),
        ],
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Semantics(
            label: 'Foto de perfil de ${user['username']}',
            image: true,
            child: CircleAvatar(
              radius: 40,
              backgroundImage: NetworkImage(user['image']),
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: MergeSemantics(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _stat(user['posts'], 'Posts'),
                  _stat(user['followers'], 'Seguidores'),
                  _stat(user['following'], 'Siguiendo'),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _stat(int number, String label) {
    return Column(
      children: [
        Text('$number', style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(label),
      ],
    );
  }

  Widget _editButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Semantics(
        button: true,
        label: 'Editar perfil',
        child: SizedBox(
          height: 48,
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () {},
            child: const Text('Editar perfil'),
          ),
        ),
      ),
    );
  }

  Widget _grid() {
    return GridView.builder(
      itemCount: posts.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
      ),
      itemBuilder: (context, index) {
        final post = posts[index];

        return Semantics(
          label:
          'Post ${index + 1} de ${posts.length}. ${post['description'] ?? "Sin descripción"}. ${post['likes']} likes',
          button: true,
          child: GestureDetector(
            onTap: () {},
            child: Image.network(post['image'], fit: BoxFit.cover),
          ),
        );
      },
    );
  }
}